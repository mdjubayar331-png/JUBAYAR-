JJBD SHOP — Android প্রোটোটাইপ

এই ZIP-এ Android Studio-তে খোলার মতো একটি সাধারণ Android project এবং অফলাইন শপিং ডেমো আছে।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
1. এটি APK নয়; এটি APK বানানোর source project।
2. পণ্য, কার্ট ও অর্ডার শুধু ডেমো/ডিভাইসের ভেতরে থাকে। অনলাইনে আপনার কাছে অর্ডার আসে না।
3. বিকাশ/নগদ পেমেন্ট আসলভাবে যুক্ত নয়।
4. অ্যাডমিন প্যানেলে লগইন নেই। এই সংস্করণ Play Store-এ প্রকাশ করবেন না।
5. বাস্তব ব্যবসার জন্য নিরাপদ admin authentication, online database/backend, order notification, privacy policy, customer support এবং payment gateway integration প্রয়োজন।

APK তৈরি:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে এই ফোল্ডার Open করুন।
3. Gradle sync শেষ হতে দিন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. Play Store-এর জন্য Build > Generate Signed Bundle / APK থেকে Android App Bundle (.aab) তৈরি করুন।
6. নিজের signing key নিরাপদে ব্যাকআপ রাখুন। Google Play Console account, store listing, privacy policy ও Play-এর বর্তমান নীতিমালা পূরণ করতে হবে।

অ্যাপের পরিচয়:
নাম: JJBD SHOP
Application ID: com.jjbdshop.app

আপনার মালিকানা:
এই প্রজেক্টটি আপনার JJBD SHOP-এর প্রাথমিক সোর্স কোড। Play Store-এ প্রকাশের আগে নিজের ডেভেলপার অ্যাকাউন্ট ও সাইনিং কী ব্যবহার করবেন।
